Steps to use the App:

1. Install Pycharm or load Visual studio
2. Open the project folder in that
3. Run app.py file
4. You will see link http://127.0.0.1:5000 so click on it or you can copy and paste on your default browser
5. Upload the image and check the prediction


References:

[1] Joseph Paul Cohen and Paul Morrison and Lan Dao. COVID-19 image data collection, arXiv, 2020. https://github.com/ieee8023/covid-chestxray-dataset

[2] The above data was transformed by the author of https://github.com/JordanMicahBennett/SMART-CT-SCAN_BASED-COVID19_VIRUS_DETECTOR/

[3] Dataset obtained from https://data.mendeley.com/datasets/8h65ywd2jr/1#__sid=js0

