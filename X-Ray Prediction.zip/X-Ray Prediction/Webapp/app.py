#import libraries
import cv2
import pickle
import numpy as np
from flask import Flask, render_template, request
#initialize
app = Flask(__name__)
#homepage
@app.route('/')
def home():
	return render_template('index.html')
#prediction button actions
@app.route('/predict', methods=['POST'])
#predict function
def predict():
	# load the PCA
	with open('pca.pkl', 'rb') as fid1:
		pca = pickle.load(fid1)
	# load the Classifier
	with open('svc.pkl', 'rb') as fid2:
		clf = pickle.load(fid2)
	#when file uploaded and submitted
	if request.method == 'POST':
		#get file
		file = request.files['file']
		#making sure file ends with .jpg, .jpeg or .png then reading the file using cv2
		if(file.filename[-2:]=='pg'):
			file.save('file.jpg')
			img = cv2.imread('file.jpg')
		elif(file.filename[-2:]=='eg'):
			file.save('file.jpeg')
			img = cv2.imread('file.jpeg')
		elif(file.filename[-2:]=='ng'):
			file.save('file.png')
			img = cv2.imread('file.png')
		#converting to grayscale
		img_gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
		#resizing
		img_ = cv2.resize(img_gray, (50, 50))
		#addding to array
		arr = np.array(img_)
		#flattening to form a sample
		x=np.array([arr.flatten()], float)
		#transforming using pca
		x=pca.transform(x)
		#predicting label on trained classifier
		y_predict = clf.predict(x)[0]
	#returning the prediction ( 1 or 0 )
	return render_template('result.html', prediction=y_predict)

if __name__ == '__main__':
	app.run(debug=True)


